<?php
// Bases de datos Biblioteca - index.php
require_once "biblioteca.php";

cabecera ( "Inicio", MENU_PRINCIPAL );

pie ();
